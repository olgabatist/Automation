package petrolStation;

/**
 * Created by Olya_Sparkle on 3/12/17.
 */
public class Truck extends Vehicle{
    public Truck() { super(); }
    public Truck(Manufacturer manufacturer, String model, FuelType fuelType) {
        super(manufacturer, model, fuelType); }


    @Override
    public String toString() {
        return manufacturer + " " + model + " "
                + fuelType;
    }

}
