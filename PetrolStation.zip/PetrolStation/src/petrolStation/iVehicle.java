package petrolStation;

/**
 * Created by Olya_Sparkle on 3/12/17.
 */
public interface iVehicle {
    void fillTank(int fuelAmount, FuelType fuelType);
     FuelType getFuelType ();
}
