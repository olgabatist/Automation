package petrolStation;

/**
 * Created by Olya_Sparkle on 3/12/17.
 */
public class Pump {
    private String pumpName;
    private int id;
    FuelType[] fuelType;
    private iVehicle vehicle;

    public Pump(String pumpName, int id, FuelType... fuelType) {
        this.pumpName = pumpName;
        this.id = id;
        this.fuelType = fuelType;
    }
    // как сделать два и больше enum в конструкторе ??? VarArg


    public void setVehicle (iVehicle vehicle) {
        this.vehicle= vehicle;}

    public String getPumpName() {
        return pumpName;
    }

    public void setPumpName(String pumpName) {
        this.pumpName = pumpName;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public FuelType[] getFuelType() {
        return fuelType;
    }

    public void setFuelType(FuelType[] fuelType) {
        this.fuelType = fuelType;
    }

    public iVehicle getVehicle() {
        return vehicle;
    }



}
