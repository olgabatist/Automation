package petrolStation;

/**
 * Created by Olya_Sparkle on 3/12/17.
 */
public class Motorbike extends Vehicle {
    public Motorbike() { super(); }
    public Motorbike(Manufacturer manufacturer, String model, FuelType fuelType) {
        super(manufacturer, model, fuelType); }


    @Override
    public String toString() {
        return manufacturer + " " + model + " "
                + fuelType;
    }

}
