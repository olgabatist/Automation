package petrolStation;

/**
 * Created by Olya_Sparkle on 3/12/17.
 */
public class Car extends Vehicle {

 public Car() { super(); }
    public Car(Manufacturer manufacturer, String model, FuelType fuelType) {
        super(manufacturer, model, fuelType); }


    @Override
    public String toString() {
        return manufacturer + " " + model + " "
                + fuelType;
    }

}
