package petrolStation;

/**
 * Created by Olya_Sparkle on 3/12/17.
 */
public enum Manufacturer {
    NISSAN,
    VOLVO,
    BMW,
    TOYOTA,
    KAWASAKI,
    DUCATI,
    MERCEDESBENZ("Mercedes Benz");

    private final String manufacturer;

    Manufacturer(){
        this.manufacturer= name();
    }

    Manufacturer(String manufacturer) {
        this.manufacturer = manufacturer;
    }
}
