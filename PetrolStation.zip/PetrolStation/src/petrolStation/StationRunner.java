package petrolStation;

import java.util.ArrayList;
import java.util.Random;

import static com.sun.xml.internal.rngom.parse.compact.CompactSyntaxConstants.WS;

/**
 * Created by Olya_Sparkle on 3/12/17.
 */
public class StationRunner {
    public static void main(String[] args) {

// собьекты кассы
        Cashier kassa1 = new Cashier("Cash only", 1, "Cash");
        Cashier kassa2 = new Cashier("Credit Cart", 2, "Credit Card");
        Cashier kassa3 = new Cashier("Cash + Card", 2, "Credit Card", "Cash");
// собьекты колонки
        Pump pump1 = new Pump("Electric Car Charger", 1, FuelType.ELECTRICITY);
        Pump pump2 = new Pump("Gasoline", 2, FuelType.EURO, FuelType.PREMIUM);
        Pump pump3 = new Pump("Diesel and Biodiesel", 3, FuelType.DIESEL, FuelType.BIODIESEL);
        Pump pump4 = new Pump("Mixed", 4, FuelType.DIESEL, FuelType.EURO, FuelType.PREMIUM);

// обьекты машины
        Car nissan1 = new Car(Manufacturer.NISSAN, "Maxima", FuelType.EURO);
        Car nissan2 = new Car(Manufacturer.NISSAN, "Leaf", FuelType.ELECTRICITY);
        Car bmw1 = new Car(Manufacturer.BMW, "528", FuelType.PREMIUM);
        Car bmw2 = new Car(Manufacturer.BMW, "318i", FuelType.EURO);
        Car toyota = new Car(Manufacturer.TOYOTA, "Prius", FuelType.ELECTRICITY);

//обьекты мотоциклы
        Motorbike ducati1 = new Motorbike(Manufacturer.DUCATI, "Diavel", FuelType.EURO);
        Motorbike ducati2 = new Motorbike(Manufacturer.DUCATI, "Panigale", FuelType.EURO);
        Motorbike kawasaki1 = new Motorbike(Manufacturer.KAWASAKI, "Ninja", FuelType.EURO);
        Motorbike kawasaki2 = new Motorbike(Manufacturer.KAWASAKI, "Ninja 650R", FuelType.EURO);

//обьекты грузовики
        Truck mercedes = new Truck(Manufacturer.MERCEDESBENZ, "Actros MP", FuelType.BIODIESEL);
        Truck volvo1 = new Truck(Manufacturer.VOLVO, "FMX", FuelType.DIESEL);
        Truck volvo2 = new Truck(Manufacturer.VOLVO, "FE", FuelType.DIESEL);

        ArrayList<Cashier> cashiers = new ArrayList<Cashier>;
        cashiers.add(kassa1);
        cashiers.add(kassa2);
        cashiers.add(kassa3);


        ArrayList<Pump> pumps = new ArrayList<Pump>;
        pumps.add(pump1);
        pumps.add(pump2);
        pumps.add(pump3);
        pumps.add(pump4);

        ArrayList<Vehicle> vehicles = new ArrayList<Vehicle>;
        // как не писать так много add???

        vehicles.add(nissan1);
        vehicles.add(nissan2);
        vehicles.add(bmw1);
        vehicles.add(bmw2);
        vehicles.add(toyota);
        vehicles.add(ducati1);
        vehicles.add(ducati2);
        vehicles.add(kawasaki1);
        vehicles.add(kawasaki2);
        vehicles.add(mercedes);
        vehicles.add(volvo1);
        vehicles.add(volvo2);

    }
    //  сравнить fuelType из Vehicle и fuelType из Pump ??? выбросить ошибку если не совпадают
    public static boolean isPumpAcceptable(Pump pump, iVehicle vehicle) {
        for (FuelType fuelType : pump.getFuelType()) {
            if (fuelType == vehicle.getFuelType()) {
               return true;}
        }
    return false;}




// выбрать рэндом Pump и Vehicle с одинаковыми fuelType
//        Random randomGenerator = new Random().nextLong();
        // ??? как сделать рэндом для разноразмерных коллекций?

/*        try {
            if randomGenerator
        }


    }*/
// сделать fillTank только если acceptPayment True

}
