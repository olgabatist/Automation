package petrolStation;

/**
 * Created by Olya_Sparkle on 3/12/17.
 */
public interface iChashier {
    void acceptPayment();
}
