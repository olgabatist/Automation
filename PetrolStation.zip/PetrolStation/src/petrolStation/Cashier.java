package petrolStation;

/**
 * Created by Olya_Sparkle on 3/12/17.
 */
public class Cashier {
    private String cashierName;
    private int id;
    private String[] paymentType;

    public Cashier(String cashierName, int id, String... paymentType) {
        this.cashierName = cashierName;
        this.id = id;
        this.paymentType= paymentType;}



}
